package com.ziqo.picodiploma.movieapp.retrofit;
import com.ziqo.picodiploma.movieapp.model.ResponseMovie;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface GetService {

    @GET("movie")
    Call<ResponseMovie> getMovies(@Query("api_key") String api_key,
                                  @Query("language") String language);
}
