package com.ziqo.picodiploma.movieapp.viewmodel;

import android.util.Log;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.ziqo.picodiploma.movieapp.model.Movie;
import com.ziqo.picodiploma.movieapp.model.ResponseMovie;
import com.ziqo.picodiploma.movieapp.retrofit.ApiClient;
import com.ziqo.picodiploma.movieapp.retrofit.GetService;
import java.util.ArrayList;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class MovieViewModel extends ViewModel {
    private static final String API_KEY = "7b028b25c0685dd492f01ea4357bd4a0";
    private String LANGUAGE = Locale.getDefault().toString();
    private MutableLiveData<ArrayList<Movie>> listMovie;

    public void setMovie() {
        Retrofit retrofit = ApiClient.getRetrofit();
        GetService getService = retrofit.create(GetService.class);
        Call<ResponseMovie> call = getService.getMovies(API_KEY, LANGUAGE);
        call.enqueue(new Callback<ResponseMovie>() {
            @Override
            public void onResponse(Call<ResponseMovie> call, Response<ResponseMovie> response) {
                if (response.isSuccessful()) {
                    listMovie.setValue((ArrayList<Movie>) response.body().getResults());
            }
        }

            @Override
            public void onFailure(Call<ResponseMovie> call, Throwable t) {
                Log.d("onFailure", t.toString());
            }
        });
    }

    public LiveData<ArrayList<Movie>> getMovie() {
        if (listMovie == null) {
            listMovie = new MutableLiveData<>();
            setMovie();
        }
        return listMovie;
    }
}
