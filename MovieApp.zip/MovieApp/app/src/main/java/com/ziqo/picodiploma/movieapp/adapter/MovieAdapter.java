package com.ziqo.picodiploma.movieapp.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.ziqo.picodiploma.movieapp.R;
import com.ziqo.picodiploma.movieapp.model.Movie;

import java.util.ArrayList;

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.MovieViewHolder> {
    private ArrayList<Movie> dataMovie = new ArrayList<>();

    public void setDataMovie(ArrayList<Movie> items) {
        dataMovie.addAll(items);
        dataMovie.clear();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public MovieViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View mView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_item_movie, viewGroup, false);
        return new MovieViewHolder(mView);
    }

    @Override
    public void onBindViewHolder(@NonNull MovieViewHolder holder, int position) {
        holder.bind(dataMovie.get(position));
    }

    @Override
    public int getItemCount() {
        return dataMovie.size();
    }

    class MovieViewHolder extends RecyclerView.ViewHolder {
        TextView textTitle;
        TextView textOverview;
        ImageView imagePoster;

        MovieViewHolder(@NonNull View itemView) {
            super(itemView);
            textTitle = itemView.findViewById(R.id.text_title);
            textOverview = itemView.findViewById(R.id.text_overview);
            imagePoster = itemView.findViewById(R.id.image_poster);
        }

        void bind(Movie movie) {
            String url_poster = "https://image.tmdb.org/t/p/w342" + movie.getPoster_path();
            Glide.with(itemView.getContext())
                    .load(url_poster)
                    .apply(new RequestOptions())
                    .into(imagePoster);
            textTitle.setText(movie.getTitle());
            textOverview.setText(movie.getOverview());
        }
    }
}
